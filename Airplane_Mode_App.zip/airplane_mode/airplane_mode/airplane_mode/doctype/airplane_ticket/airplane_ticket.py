import frappe
import random
from frappe import _
from frappe.model.document import Document

class AirplaneTicket(Document):
    def validate(self):
        # Run existing checks
        self.remove_duplicate_addons()
        self.calculate_total_amount()

        # Fetch flight details as well
        self.fetch_flight_details()

    def remove_duplicate_addons(self):
        seen_items = set()
        unique_addons = []
        for addon in self.add_ons:
            if addon.item not in seen_items:
                seen_items.add(addon.item)
                unique_addons.append(addon)
        self.add_ons = unique_addons

    def calculate_total_amount(self):
        total_addons_amount = sum(addon.amount or 0 for addon in self.add_ons)
        self.total_amount = (self.flight_price or 0) + total_addons_amount

    def before_submit(self):
        if self.status != "Boarded":
            frappe.throw(_("Cannot submit Airplane Ticket because status is not 'Boarded'. Current status: {0}").format(self.status))

    # STEP 1: Random seat function
    def get_random_seat(self):
        row = random.randint(1, 40)  # Assuming 40 rows
        seat_letter = random.choice(["A", "B", "C", "D", "E"])
        return f"{row}{seat_letter}"

    # STEP 2: Set seat before insert
    def before_insert(self):
        if not self.seat:
            self.seat = self.get_random_seat()

    # ✅ Corrected fetch flight details
    def fetch_flight_details(self):
        if self.flight:  # flight is the Link field to Airplane Flight
            flight = frappe.get_doc("Airplane Flight", self.flight)
            self.departure_date = flight.date_of_departure
            self.departure_time = flight.time_of_departure
            self.duration = flight.duration
    def validate(self):
        self.check_capacity()

    def check_capacity(self):
        flight_doc = frappe.get_doc("Airplane Flight", self.flight)
        # Get the airplane's capacity
        airplane = frappe.get_doc("Airplane", flight_doc.airplane)
        capacity = airplane.capacity

        # Count existing tickets for this flight
        existing_tickets = frappe.db.count(
            "Airplane Ticket",
            {"flight": self.flight}
        )

        # Include this ticket being created
        if existing_tickets >= capacity:
            frappe.throw(f"Cannot create ticket: Flight already has {capacity} tickets, which is the maximum capacity of the airplane.")
    def before_insert(self):
        if self.flight:
            flight = frappe.get_doc("Airplane Flight", self.flight)
            self.gate_number = flight.gate_number