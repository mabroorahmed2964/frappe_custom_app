# Copyright (c) 2025, Mabroor Ahmad and contributors
# For license information, please see license.txt

import frappe
from frappe.website.website_generator import WebsiteGenerator
from datetime import datetime
from frappe.utils.background_jobs import enqueue
class AirplaneFlight(WebsiteGenerator):

    def autoname(self):
        # Get linked airplane name
        airplane = frappe.get_doc("Airplane", self.airplane)
        # Month-Year
        month_year = datetime.now().strftime("%m-%Y")
        # Name format
        self.name = f"{airplane.name}-{month_year}-.#####"
        # Generate with sequence
        self.name = frappe.model.naming.make_autoname(self.name)

    def on_submit(self):
        # When submitted, status should be Completed
        self.db_set("status", "Completed")

    def get_formatted_duration(self):
        if not self.duration:
            return ""

        total_seconds = int(self.duration)
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60

        formatted_string = ""
        if hours > 0:
            formatted_string += f"{hours}h "
        if minutes > 0:
            formatted_string += f"{minutes}m"

        return formatted_string.strip()

    
    def on_update(self):
        # Background job enqueue karna
        frappe.enqueue(
            "airplane_mode.airport_shop_management.doctype.airplane_flight.airplane_flight.update_ticket_gate_numbers",
            flight=self.name,
            gate_number=self.gate_number
        )

    def update_ticket_gate_numbers(flight, gate_number):
        tickets = frappe.get_all("Airplane Ticket", filters={"flight": flight}, pluck="name")
        for ticket in tickets:
         t = frappe.get_doc("Airplane Ticket", ticket)
         t.gate_number = gate_number
         t.save(ignore_permissions=True)  
