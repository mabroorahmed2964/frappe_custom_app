import frappe

def execute(filters=None):
    # Step 1: Get all airlines
    airlines = frappe.get_all("Airline", fields=["name"])
    revenue_map = {a.name: 0 for a in airlines}

    # Step 2: Get flights with their airline
    flights = frappe.get_all("Airplane Flight", fields=["name", "airline"])
    flight_airline_map = {f.name: f.airline for f in flights if f.airline}

    # Step 3: Get tickets (flight + flight_price)
    tickets = frappe.get_all(
        "Airplane Ticket",
        fields=["flight", "flight_price"]
    )

    for t in tickets:
        airline = flight_airline_map.get(t.flight)
        if airline:
            revenue_map[airline] += t.flight_price or 0

    # Step 4: Prepare data for report
    data = []
    total_revenue = 0
    for airline in airlines:
        revenue = revenue_map.get(airline.name, 0)
        total_revenue += revenue
        data.append({
            "airline": airline.name,
            "revenue": revenue
        })

    # Columns
    columns = [
        {
            "label": "Airline",
            "fieldname": "airline",
            "fieldtype": "Link",
            "options": "Airline",
            "width": 200,
        },
        {
            "label": "Revenue",
            "fieldname": "revenue",
            "fieldtype": "Currency",
            "width": 150,
        },
    ]

    # Donut Chart
    chart = {
        "data": {
            "labels": [d["airline"] for d in data],
            "datasets": [{"values": [d["revenue"] for d in data]}]
        },
        "type": "donut",
        "height": 250,
    }

    # Summary
    summary = [
        {"label": "Total Revenue", "value": total_revenue, "indicator": "Green"},
    ]

    return columns, data, None, chart, summary
