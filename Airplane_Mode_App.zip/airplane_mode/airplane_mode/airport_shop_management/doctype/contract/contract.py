# Copyright (c) 2025, Mabroor Ahmad  and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document
from frappe.utils import add_months, getdate

class Contract(Document):
    def before_insert(self):
        self.create_payment_schedule()

    def create_payment_schedule(self):
        start = getdate(self.start_date)
        end = getdate(self.end_date)
        months = (end.year - start.year) * 12 + (end.month - start.month) + 1

        # Clear existing child table entries (just in case)
        self.set("payment_schedule_item", [])

        for i in range(months):
            due_date = add_months(start, i)
            self.append("payment_schedule_item", {
                "due_date": due_date,
                "amount": self.rent_amount
            })

        
    