# Copyright (c) 2025, Mabroor Ahmad  and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from frappe.website.website_generator import WebsiteGenerator


class Shop(WebsiteGenerator):
	pass
def before_insert(doc, method):
    if doc.doctype == "Shop" and not doc.rent_amount:
        settings = frappe.get_single("Airport Shop Settings")
        if settings.default_rent_amount:
            doc.rent_amount = settings.default_rent_amount
def get_context(context):
    context.shops = frappe.get_all("Shop",
        filters={"is_published": 1}, 
        fields=["shop_name", "airport", "rent_amount", "status",]
    )           