// Copyright (c) 2025, Mabroor Ahmad  and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Rent Payment", {
// 	refresh(frm) {

// 	},
// });
