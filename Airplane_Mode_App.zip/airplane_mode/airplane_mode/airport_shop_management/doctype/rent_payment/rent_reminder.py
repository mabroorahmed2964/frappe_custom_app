import frappe
from frappe.utils import today, add_months

def send_rent_reminders():
    # Get global settings
    settings = frappe.get_single("Airport Shop Settings")

    # Agar reminders disable hain to kuch mat karo
    if not settings.enable_rent_reminders:
        return

    contracts = frappe.get_all(
        "Contract",
        fields=["name", "tenant", "end_date", "rent_amount"]
    )

    for c in contracts:
        tenant = frappe.get_doc("Tenant", c.tenant)

        message = f"""
        Dear {tenant.tenant_name},

        This is a reminder that your monthly rent of {c.rent_amount} is due.
        Please make the payment at your earliest.

        Regards,
        Airport Authority
        """

    print(f"📩 Sending reminder to {tenant.email}")
    print(message)
